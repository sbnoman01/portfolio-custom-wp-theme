<?php


// =======================================
// ====== CodeStar Intigration ===========
// =======================================

require_once get_theme_file_path() .'/inc/codestar-framework/codestar-framework.php';
require_once get_theme_file_path() .'/inc/codestar-framework/samples/options.php';

// Define path and URL to the ACF plugin.
define( 'MY_ACF_PATH', get_stylesheet_directory() . '/inc/advanced-custom-fields/' );
define( 'MY_ACF_URL', get_stylesheet_directory_uri() . '/inc/advanced-custom-fields/' );

// Include the ACF plugin.
include_once( MY_ACF_PATH . 'acf.php' );

// Customize the url setting to fix incorrect asset URLs.
add_filter('acf/settings/url', 'my_acf_settings_url');
function my_acf_settings_url( $url ) {
    return MY_ACF_URL;
}

// (Optional) Hide the ACF admin menu item.
add_filter('acf/settings/show_admin', 'my_acf_settings_show_admin');
function my_acf_settings_show_admin( $show_admin ) {
    return false;
}


// load css/js fiels
function load_assets_ajax_noman(){
    // ================================
    // Load all CSS fiels==============
    // ================================

   
    // owl carousel
    wp_enqueue_style( 'reset-theme', get_template_directory_uri() . '/css/reset.css', array(),'1.1','all');
    wp_enqueue_style( 'bootstrap-grid', get_template_directory_uri() . '/css/bootstrap-grid.min.css', array(),'1.1','all');
    wp_enqueue_style( 'animations', get_template_directory_uri() . '/css/animations.css', array(),'1.1','all');
    wp_enqueue_style( 'perfect-scrollbar', get_template_directory_uri() . '/css/perfect-scrollbar.css', array(),'1.1','all');
    wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/css/owl.carousel.css', array(),'1.1','all');
    wp_enqueue_style( 'magnific-popup', get_template_directory_uri() . '/css/magnific-popup.css', array(),'1.1','all');
    wp_enqueue_style( 'main', get_template_directory_uri() . '/css/main.css', array(),'1.1','all');
   

    // ================================
    // Load all js fiels===============
    // ================================

    wp_enqueue_script('modernizr-custom', get_template_directory_uri() . '/js/modernizr.custom.js', array('jquery'), '1.0',true);
    wp_enqueue_script('animating', get_template_directory_uri() . '/js/animating.js', array('jquery'), '1.0',true);
    wp_enqueue_script('imagesloaded', get_template_directory_uri() . '/js/imagesloaded.pkgd.min.js', array('jquery'), '1.0',true);
    wp_enqueue_script('perfect-scrollbar', get_template_directory_uri() . '/js/perfect-scrollbar.min.js', array('jquery'), '1.0',true);
    wp_enqueue_script('jquery-shuffle', get_template_directory_uri() . '/js/jquery.shuffle.min.js', array('jquery'), '1.0',true);
    wp_enqueue_script('masonry-pkgd', get_template_directory_uri() . '/js/masonry.pkgd.min.js', array('jquery'), '1.0',true);
    wp_enqueue_script('wl.carousel', get_template_directory_uri() . '/js/owl.carousel.min.js', array('jquery'), '1.0',true);
    wp_enqueue_script('magnific-popup', get_template_directory_uri() . '/js/jquery.magnific-popup.min.js', array('jquery'), '1.0',true);
    wp_enqueue_script('validator', get_template_directory_uri() . '/js/validator.js', array('jquery'), '1.0',true);
    wp_enqueue_script('main', get_template_directory_uri() . '/js/main.js', array('jquery'), '1.0',true);
   // wp_enqueue_script('modernizr', get_template_directory_uri() . '/js/modernizr.js', array('jquery'), '1.0',true);
   
}
add_action( 'wp_enqueue_scripts', 'load_assets_ajax_noman');



