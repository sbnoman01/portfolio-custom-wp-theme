<?php
/**
 * Template Name: preview
 */

$options = get_option('beauty_smiles_theme_options');
//echo $options['paypalMail']
get_header(); ?>

<?php

global $wpdb;
if(isset($_POST['paynow'])){


$tm_date = $_POST['tm_date'];
$tm_name = $_POST['tm_name'];
$tm_phone = $_POST['phone'];
$tm_email = $_POST['email'];
$tm_time = $_POST['time'];

$tm_amount = $_POST['tm_amount'];

$wpdb->get_results("SELECT * FROM ".$wpdb->prefix."tmpreview WHERE tm_date='$tm_date' and tm_time='$tm_time'"); 

 $total = $wpdb->num_rows;
if($total==0){
$wpdb->query("INSERT INTO `".$wpdb->prefix."tmpreview` (`id`, `tm_date`, `tm_name`, `tm_phone`, `tm_email`, `tm_time`) VALUES (NULL, '$tm_date', '$tm_name', '$tm_phone', '$tm_email', '$tm_time')");

$lastid = $wpdb->insert_id;

echo "<h1 class='redirect-paypal'> You're redirecting to the paypal to compleate transition</h1>";
?>

<form class="contact_form booking_form"  id="payuForm" action="https://www.paypal.com/cgi-bin/webscr" method="post">

   <!-- https://www.paypal.com/cgi-bin/webscr https://www.sandbox.paypal.com/cgi-bin/webscr -->

  <input type="hidden" name="cmd" value="_xclick">
            <input type="hidden" name="business" value="<?php echo $options['paypalMail'] ?>">
            <input style="color:white;" id="myText" type="text" name="amount" value="<?php echo $tm_amount; ?>" placeholder="Ammount To be paid">

            <input type="hidden" name="no_shipping" value="0">
            <input type="hidden" name="no_note" value="1">
            <input type="hidden" name="currency_code" value="USD">
            <input type="hidden" name="lc" value="AU">
            <input type="hidden" name="bn" value="PP-BuyNowBF">
            <input type="hidden" name="return" value="https://beautifulsmilesandsounds.com/payment-success/?id=<?php echo $lastid; ?>">


            <!-- <button type="submit">Pay with PayPal!</button> -->
        </form>



<script type="text/javascript">
   document.getElementById('payuForm').submit();
</script>


<?php
}else{ 
 echo "<script>alert('slot already booked for this time')</script>";
echo '<script>window.setTimeout( show_popup, 500000 );</script>';
echo '<script>window.location.href="https://beautifulsmilesandsounds.com/book-date/"</script>';

	?>
<?php
}	
}

?>

