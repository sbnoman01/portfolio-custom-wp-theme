<?php $options = get_option( 'ajax_theme_options' ); ?>
<!DOCTYPE html>
<html lang="en" class="no-js">
  
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
    <title>BreezyCV - Resume / CV / vCard Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="BreezyCV - Resume / CV / vCard Template" />
    <meta name="keywords" content="vcard, resposnive, retina, resume, jquery, css3, bootstrap, Material CV, portfolio" />
    <meta name="author" content="lmpixels" />
    <link rel="shortcut icon" href="favicon.ico">

    <?php wp_head(); ?>

    
</head>
<body>
    <!-- Animated Background -->
    <div class="lm-animated-bg" style="background-image: url(img/main_bg.png);"></div>
    <!-- /Animated Background -->

    <!-- Loading animation -->
    <!-- <div class="preloader">
      <div class="preloader-animation">
        <div class="preloader-spinner">
        </div>
      </div>
    </div> -->
    <!-- /Loading animation -->

    <div class="page">
      <div class="page-content">

          <header id="site_header" class="header mobile-menu-hide">
            <div class="header-content">
              <div class="header-photo">
             
                <img src=" <?php echo $options['logo-main-header']['url'] ?>" alt="Alex Smith">
              </div>
              <div class="header-titles">
                <h2><?php echo $options['header-title']; ?></h2>
                <h4><?php echo $options['header-sub-Title']; ?></h4>
              </div>
            </div>

            <ul class="main-menu">
              <li class="active">
                <a href="#home" class="nav-anim">
                  <span class="menu-icon lnr lnr-home"></span>
                  <span class="link-text">Home</span>
                </a>
              </li>
              <li>
                <a href="#about-me" class="nav-anim">
                  <span class="menu-icon lnr lnr-user"></span>
                  <span class="link-text">About Me</span>
                </a>
              </li>
              <li>
                <a href="#resume" class="nav-anim">
                  <span class="menu-icon lnr lnr-graduation-hat"></span>
                  <span class="link-text">Resume</span>
                </a>
              </li>
              <li>
                <a href="#portfolio" class="nav-anim">
                  <span class="menu-icon lnr lnr-briefcase"></span>
                  <span class="link-text">Portfolio</span>
                </a>
              </li>
              <li>
                <a href="#blog" class="nav-anim">
                  <span class="menu-icon lnr lnr-book"></span>
                  <span class="link-text">Blog</span>
                </a>
              </li>
              <li>
                <a href="#contact" class="nav-anim">
                  <span class="menu-icon lnr lnr-envelope"></span>
                  <span class="link-text">Contact</span>
                </a>
              </li>
            </ul>

            <div class="social-links">
              <ul>
                  <?php 
                    $social_header = $options['header_social_icons'];
                  foreach($social_header as $links){
                      extract($links);
                      echo "<li><a href='$header_social_link' target='_blank'><i class='$header_social_icon'></i></a></li>";
                  }
                  ?>
              </ul>
            </div>
            <?php if($options['header-sub-Title']){ ?>
            <div class="header-buttons">
              <a href="<?php echo $options['header-button-url']; ?>" target="_blank" class="btn btn-primary"><?php echo $options['header-button-name']; ?></a>
            </div>
                <?php } ?>
            <div class="copyrights">© 2020 All rights reserved.</div>
          </header>