<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.


// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'ajax_theme_options';
  
    //
    // Create options
    CSF::createOptions( $prefix, array(
      'menu_title' => 'Ajax Portfolio',
      'menu_slug'  => 'ajax-Portfolio-theme-options',
      'framework_title' => 'AJAX PORTFOLIO <small>by NOMAN</small>'
    ) );
  

    //
    // Create a section
    CSF::createSection( $prefix, array(
      'title'  => 'Genarel',
      'icon'   => 'fas fa-home',
      'fields' => array(
  
        //
        // A text field
        array(
          'id'    => 'logo-main-header',
          'type'  => 'media',
          'default' => get_template_directory() . '/media/logo.png',
          'title' => 'Website Logo',
        ),
        array(
          'id'    => 'slider-shortcode',
          'type'  => 'text',
          'title' => 'Slider Shortcode'
        ),
        array(
          'id'    => 'page-background',
          'type'  => 'media',
          'title' => 'Page Background',
          'default' => get_template_directory() . './assets/img/page-bg.png'
        ),
        array(
          'id'    => 'page-background-possitionx',
          'type'  => 'text',
          'title' => 'Background Possition-X',
          'placeholder' => '100%',
          'default' => '100%'
        )
      )
    ) );
  
    // Header section
    CSF::createSection( $prefix, array(
      'title'  => 'Header',
      'icon'   => 'fas fa-home',
      'fields' => array(
  
        //
        // A text field
        array(
          'id'    => 'logo-main-header',
          'type'  => 'media',
          'default' => get_template_directory() . '/media/logo.png',
          'title' => 'Header Logo',
        ),
        array(
          'id'    => 'header-title',
          'type'  => 'text',
          'title' => 'Title',
          'default' => "WP NOMAN"
        ),
        array(
          'id'    => 'header-sub-Title',
          'type'  => 'text',
          'title' => 'Title sub title',
          'default' => "Web Designer | Developer | Programmer"
        ),
        array(
          'id'    => 'header_social_icons',
          'type'  => 'group',
          'title' => 'Social Links',
          'fields'  => array(
            array(
              'id'  => 'header_social_title',
              'title'=> 'Social Name',
              'type'  => 'text',
              'placeholder' => 'Facebook'
            ),
            array(
              'id'  => 'header_social_icon',
              'title' => 'Select your icon',
              'type'  => 'icon'
            ),
            array(
              'id'  => 'header_social_link',
              'title' => 'Social Link',
              'type'  => 'text',
              'placeholder'  => 'https://facebook.com/ami.sb.noman'
            )
          )
        ),
        array(
          'id'    => 'header-button-name',
          'type'  => 'text',
          'title' => 'Button Name'
        ),
        array(
          'id'    => 'header-button-url',
          'type'  => 'text',
          'title' => 'Button URL'
        )
        
      )
    ) );
  
      // #home section
      CSF::createSection( $prefix, array(
        'title'  => 'Home',
        'icon'   => 'fas fa-home',
        'fields' => array(
    
          //
          // A text field
          array(
            'id'    => 'logo-main-home',
            'type'  => 'media',
            'default' => get_template_directory() . '/media/logo.png',
            'title' => 'Home image'
          ),
          array(
            'id'    => 'home_author-name',
            'type'  => 'text',
            'title' => 'Title',
            'default' => "WP NOMAN"
          ),
          array(
            'id'    => 'header-sub-Title',
            'type'  => 'text',
            'title' => 'Title sub title',
            'default' => "Web Designer | Developer | Programmer"
          ),
          array(
            'id'    => 'home_author-name',
            'type'  => 'text',
            'title' => 'Text-Slider',
            'default' => "Web Designer | Developer | Programmer"
          ),
          
        )
      ) );
    
          // backup and export
    CSF::createSection( $prefix, array(
      'title'  => 'Import/Export',
      'icon'   => 'fas fa-portrait',
      'fields' => array(
        array(
  'type' => 'backup',
),
        )));
  }